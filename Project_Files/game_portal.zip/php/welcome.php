<?php
   include('session.php');
         header("Location: http://localhost/game_portal/index1.php");

?>
  
                