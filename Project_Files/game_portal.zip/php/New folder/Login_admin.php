<?php
   include("config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['logEmail']);
      $mypassword = mysqli_real_escape_string($db,$_POST['logPass']); 
      
      $sql = "SELECT email FROM admin_info WHERE email = '$myusername' AND password = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
     // $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
    //     session_register("myusername");
         $_SESSION['login_user'] = $myusername;
 
         header("location: welcome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
		 //echo  $error; 
			echo '<script language="javascript">';
			echo 'alert("Your Login Name or Password is invalid")';
			echo '</script>';
         header("location: login_admin.php");

		 
      }
   }
?>
 
<html>

<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="Pragmatic Mate s.r.o. - http://pragmaticmates.com">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="shortcut icon" href="#">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" media="screen, projection">
    <link rel="stylesheet" type="text/css" href="libraries/chosen/chosen.min.css" media="screen, projection">
    <link rel="stylesheet" type="text/css" href="libraries/pictopro-outline/pictopro-outline.css" media="screen, projection">
    <link rel="stylesheet" type="text/css" href="libraries/pictopro-normal/pictopro-normal.css" media="screen, projection">
    <link rel="stylesheet" type="text/css" href="libraries/colorbox/colorbox.css" media="screen, projection">
    <link rel="stylesheet" type="text/css" href="libraries/jslider/bin/jquery.slider.min.css" media="screen, projection">
    <link rel="stylesheet" type="text/css" href="assets/css/carat.css" media="screen, projection">
 
    <link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:100,400,700,400italic,700italic" rel="stylesheet" type="text/css"  media="screen, projection">
 
    <title>Carat | Car Dealer &amp; Booking HTML Template</title>
</head>

    <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='assets/text/css'>
    
    <link rel="stylesheet" href="assets/css/normalize.css">

            <link rel="stylesheet" href="assets/css/login-admin.css">

        <link rel="stylesheet" href="assets/css/style.css">
<body>
  <div class="topbar gray">
	<div class="container">
		<div class="row">
            <div class="col-md-6 col-xs-12 header-top-left">
                <div>
                    <div class="news">
                        <div class="inner">
                                <ul class="news-list">
                                    <li>Chrysler plans new <a href="#">product</a> at Windsor, Ontario, plant, report says</li>
                                    <li>Tesla retail model faces new legal challenge in Ohio</li>
                                    <li>Toyota revealing new model</li>

                                </ul><!-- /.news-list -->
                        </div><!-- /.inner -->
                    </div><!-- /.news -->
                </div>
            </div>

            <div class="col-md-6 col-xs-12 header-top-right">
                <div>
                    <div class="social">
                        <div class="inner">
                               <!-- <ul class="social-links">
                                    <li class="social-icon google-plus"><a href="#">Google+</a></li>
                                    <li class="social-icon youtube"><a href="#">YouTube</a></li>
                                    <li class="social-icon twitter"><a href="#">Twitter</a></li>
                                    <li class="social-icon pinterest"><a href="#">Pinterest</a></li>
                                    <li class="social-icon facebook"><a href="#">Facebook</a></li>
                                </ul><!-- /.social-links -->
                        </div><!-- /.inner -->
                    </div><!-- /.social -->

                    <div class="languages">
                        <ul>
                            <li><a href="register.html"><img src="assets/img/icons/login_icon.png" <!--height="22" width="22"--></a></li> 
                           <li> <a href="login_admin.php"><i class="icon-user"></i><img src="assets/img/icons/user_login_man-512.png" <!--height="22" width="22"--></a></li> 
                        </ul>
                    </div><!-- /.languages -->

                    <form class="navbar-form search-form" role="search">
                        <div class="input-group">
                        	<input type="text" class="form-control" placeholder="Search" required="required">

                        	<span class="input-group-btn">
                        		<button type="submit" class="btn btn-default"><i class="icon icon-normal-magnifier"></i></button>
                        	</span><!-- /.input-group-btn -->
                        </div><!-- /.input-group -->                     
                    </form><!-- /.search-form -->
                </div>
            </div><!-- /.col-md-5 -->
		</div><!-- /.row -->
	</div><!-- /.container -->
</div><!-- /.topbar -->

<header id="header">
	<div class="header-inner">
		<div class="container">
			<div class="row">
				<div class="col-md-12 clearfix">
					<div class="brand">
						<div class="logo">
							<a href="/">
								<img src="assets/img/logo.png" alt="Carat HTML Template">
							</a>
						</div><!-- /.logo -->

						<div class="slogan">Car Rental, Dealership,<br>Magazine Template</div><!-- /.slogan -->
					</div><!-- /.brand -->
					
					<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".navbar-collapse">
					    <span class="sr-only">Toggle navigation</span>
					    <span class="icon-bar"></span>
					    <span class="icon-bar"></span>
					    <span class="icon-bar"></span>
					</button>

					<nav class="collapse navbar-collapse navbar-collapse" role="navigation">
						<ul class="navigation">
						<li><a href="index.php">Home</a></li>						

						<li class="menuparent has-regularmenu">
							<a href="magazine.html">Features</a>

							<div class="regularmenu">
								<ul class="regularmenu-inner">
									<li><a href="detail.html"><i class="icon icon-normal-car"></i> Car Detail</a></li>
                                                                        <li><a href="filter.html"><i class="icon icon-normal-magnifier"></i> Search results</a></li>
                                                                        <li><a href="about.html"><i class="icon icon-normal-profile-checkbox"></i> About</a></li>
									<li><a href="faq.html"><i class="icon icon-normal-collage-hat"></i> FAQ</a></li>
									<li><a href="pricing.html"><i class="icon icon-normal-coins"></i> Pricing</a></li>
									<li><a href="blog.html"><i class="icon icon-normal-question-mark"></i> Blog</a></li>
									<li><a href="article.html"><i class="icon icon-normal-file-text"></i>Article Detail</a></li>
									<li><a href="404.html"><i class="icon icon-normal-cog-wheel"></i>Page Not Found</a></li>
								</ul><!-- /.regularmenu-inner -->
							</div><!-- /.regularmenu -->
						</li>

						<li class="menuparent has-regularmenu">
							<a href="#">Reservation</a>

							<div class="regularmenu">
								<ul class="regularmenu-inner">
									<li><a href="rental-1.html"><strong>1.</strong> Request Reservation</a></li>
									<li><a href="rental-2.html"><strong>2.</strong> Select Your Car</a></li>
									<li><a href="rental-3.html"><strong>3.</strong> Extra Features</a></li>
									<li><a href="rental-4.html"><strong>4.</strong> Review &amp; Checkout</a></li>
								</ul><!-- /.regularmenu-inner -->
							</div><!-- /.regularmenu -->
						</li>

						<li><a href="magazine.html">Magazine</a></li>
						<li class="menuparent has-megamenu">
							<a href="#">Popular</a>

							<div class="megamenu">
								<div class="megamenu-inner clearfix">
									<div class="col-md-4 col-sm-6 col-xs-12">
										<div class="block random-cars">
											<div class="title">
												<h2>Popular Cars</h2>
											</div><!-- /.title -->

											<div class="items">
												<div class="teaser-item-wrapper">
													<div class="teaser-item">
													    <div class="title">
													        <a href="detail.html">Toyota Landcruiser</a>
													    </div><!-- /.title -->

								    					<div class="subtitle">Windsor Locks, CT </div><!-- /.subtitle -->

													    <div class="row">
													        <div class="picture-wrapper col-md-4 col-sm-4 col-xs-4">
													            <div class="picture">
													                <a href="detail.html">
													                	<span class="hover">
													                		<span class="hover-inner">
													                			<i class="icon icon-normal-link"></i>
													                		</span><!-- /.hover-inner -->
													                	</span><!-- /.hover -->

													                    <img src="assets/img/content/toyota4.jpg" alt="#">
													                </a>
													            </div><!-- /.picture -->
													        </div><!-- /.col-md-5 -->

													        <div class="content-wrapper col-md-8 col-sm-8 col-xs-8">
													            <div class="price">$9,799</div>
													            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu vulputate neque.</p>
													        </div><!-- /.col-md-7 -->
													    </div><!-- /.row -->
													</div><!-- /.teaser-item -->
												</div><!-- /.teaser-item-wrapper -->

												<div class="teaser-item-wrapper">												
													<div class="teaser-item">
													    <div class="title">
													        <a href="detail.html">Toyota Landcruiser</a>
													    </div><!-- /.title -->

								    					<div class="subtitle">Windsor Locks, CT </div><!-- /.subtitle -->

													    <div class="row">
													        <div class="picture-wrapper col-md-4 col-sm-4 col-xs-4">
													            <div class="picture">
													                <a href="detail.html">
													                	<span class="hover">
													                		<span class="hover-inner">
													                			<i class="icon icon-normal-link"></i>
													                		</span><!-- /.hover-inner -->
													                	</span><!-- /.hover -->

                                                                                                                            <img src="assets/img/content/toyota6.jpg" alt="#">
													                </a>
													            </div><!-- /.picture -->
													        </div><!-- /.col-md-5 -->

													        <div class="content-wrapper col-md-8 col-sm-8 col-xs-8">
													            <div class="price">$9,799</div>
													            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu vulputate neque.</p>
													        </div><!-- /.col-md-7 -->
													    </div><!-- /.row -->
													</div><!-- /.teaser-item -->
												</div><!-- /.teaser-item-wrapper -->
											</div><!-- /.items -->
										</div><!-- /.block -->				
									</div>

									<div class="col-md-3 col-sm-6">
										<h2>Recent Posts</h2>

										<div class="latest-reviews block">
											<div class="block-inner">
												<div class="inner">
													<div class="item-wrapper">
														<div class="item">
															<div class="title">
																<a href="detail.html">Toyota Landcruiser</a>
															</div><!-- /.title -->

															<div class="date">10/12/2013</div><!-- /.date -->

															<div class="description">
																<p>
																	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu vulputate...
																</p>
															</div><!-- /.description -->
														</div><!-- /.item -->
													</div><!-- /.item-wrapper -->

													<div class="item-wrapper">
														<div class="item">
															<div class="title">
																<a href="detail.html">Toyota RAV</a>
															</div><!-- /.title -->

															<div class="date">12/12/2013</div><!-- /.date -->

															<div class="description">
																<p>
																	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu vulputate...
																</p>
															</div><!-- /.description -->
														</div><!-- /.item -->			
													</div><!-- /.item-wrapper -->

													<div class="item-wrapper">
														<div class="item">
															<div class="title">
																<a href="detail.html">Toyota 4Runner</a>
															</div><!-- /.title -->

															<div class="date">20/12/2013</div><!-- /.date -->

															<div class="description">
																<p>
																	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu vulputate...
																</p>
															</div><!-- /.description -->
														</div><!-- /.item -->			
													</div><!-- /.item-wrapper -->
												</div><!-- /.inner -->
											</div><!-- /.block-inner -->
										</div><!-- /.block -->									
									</div>

									<div class="col-md-5 col-sm-12">
										<h2>Our Brands</h2>								

										<div class="brands block">
											<div class="row">
												<div class="col-md-6 col-sm-6">
													<ul>
														<li><a href="#"><img src="assets/img/brands/ford.png" alt="#"> Ford</a></li>
														<li><a href="#"><img src="assets/img/brands/toyota.png" alt="#"> Toyota</a></li>
														<li><a href="#"><img src="assets/img/brands/kia.png" alt="#"> Kia</a></li>
														<li><a href="#"><img src="assets/img/brands/opel.png" alt="#"> Opel</a></li>
														<li><a href="#">&nbsp;<img src="assets/img/brands/bmw.png" alt="#"> BMW</a></li>
													</ul>
												</div><!-- /.col-md-6 -->

												<div class="col-md-6 col-sm-6">
													<ul>
														<li><a href="#"><img src="assets/img/brands/audi.png" alt="#"> Audi</a></li>
														<li><a href="#"><img src="assets/img/brands/honda.png" alt="#"> Honda</a></li>
														<li><a href="#"><img src="assets/img/brands/volkswagen.png" alt="#"> Volkswagen</a></li>
														<li><a href="#"><img src="assets/img/brands/peugot.png" alt="#"> Peugot</a></li>
														<li><a href="#"><img src="assets/img/brands/chevrolet.png" alt="#"> Chevrolet</a></li>
													</ul>
												</div><!-- /.col-md-6 -->											
											</div><!-- /.row -->
										</div><!-- /.brands -->
									</div><!-- /.col-md-5 -->
								</div><!-- /.megamenu-inner -->
							</div><!-- /.mega-menu-->
						</li>
						<li><a href="contact.html">Contact</a></li>
						</ul><!-- /.nav -->
					</nav>
				</div><!-- /.col-md-12 -->
			</div><!-- /.row -->
		</div><!-- /.container -->
	</div><!-- /.header-inner -->
</header><!-- /#header -->


<div class="infobar">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ol class="breadcrumb pull-left">
		  			<li><a href="#">Home</a></li>
		  			<li><a href="#">Featured Cars</a></li>
		  			<li class="active">Buy</li>
				</ol>

				<div class="contact pull-right">
					<div class="contact-item phone">
						<div class="label"><i class="icon icon-normal-mobile-phone"></i></div><!-- /.label -->
						<div class="value">123-456-789</div><!-- /.value -->
					</div><!-- /.phone -->

					<div class="contact-item mail">
						<div class="label"><i class="icon icon-normal-mail"></i></div><!-- /.label -->
						<div class="value"><a href="mailto:example@example.com">example@example.com</a></div><!-- /.value -->
					</div><!-- /.mail -->

					<div class="contact-item opening">
						<div class="label"><i class="icon icon-normal-clock"></i></div><!-- /.label -->
						<div class="value">Mon - Sun: 8:00 - 16:00</div><!-- /.value -->
					</div><!-- /.opening -->
				<!-- </div><!-- /.contact -->
			</div><!-- /.col-md-12 -->
		</div><!-- /.row -->
	</div><!-- /.container -->
 
        </div>
        <!-- /.container -->
    </div>
    <!-- /#page-heading -->
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
<div class="form">
      
       <ul class="tab-group">
        <!--<li class="tab "><a href="#signup">Sign Up</a></li>-->
        <li class="tab active"><a >Log In</a></li>
      </ul>
      
      <!--<div class="tab-content">
        <div id="signup">   
          <h1>Sign Up for Free</h1>
          
          <form action="assets/php/signup.php" method="post">
          
          <div class="top-row">
            <div class="field-wrap">
              <label>
                First Name<span class="req">*</span>
              </label>
              <input type="text" name = "fn"required autocomplete="off" />
            </div>
        
            <div class="field-wrap">
              <label>
                Last Name<span class="req">*</span>
              </label>
              <input type="text" name="ln" required autocomplete="off"/>
            </div>
          </div>

          <div class="field-wrap">
            <label>
              Email Address<span class="req">*</span>
            </label>
            <input type="email" name="email" id="email" required autocomplete="off"/>
          </div>
		  
		  <div class="field-wrap">
            <label>
              Phone Number<span class="req">*</span>
            </label>
            <input type="text" name="phone" required autocomplete="off"/>
          </div>
          
		  
		  
		  
		  
          <div class="field-wrap">
            <label>
              Set A Password<span class="req">*</span>
            </label>
            <input type="password" name="pass"required autocomplete="off"/>
          </div>
		  
		  <div class="field-wrap">
            <label>
              address<span class="req">*</span>
            </label>
            <input type="address" name="address"required autocomplete="off"/>
          </div>
		  
		  <div class="field-wrap">
			<label>
 
            </label>						
	<select id="state" name="state" onchange="change_state(this.value)" class="frm-field required">
				 <option value="null"> State</option>         
				 <option value="AL">Alabama</option>
				<option value="AK">Alaska</option>
				<option value="AZ">Arizona</option>
				<option value="AR">Arkansas</option>
				<option value="CA">California</option>
				<option value="CO">Colorado</option>
				<option value="CT">Connecticut</option>
				<option value="DE">Delaware</option>
				<option value="DC">District Of Columbia</option>
				<option value="FL">Florida</option>
				<option value="GA">Georgia</option>
				<option value="HI">Hawaii</option>
				<option value="ID">Idaho</option>
				<option value="IL">Illinois</option>
				<option value="IN">Indiana</option>
				<option value="IA">Iowa</option>
				<option value="KS">Kansas</option>
				<option value="KY">Kentucky</option>
				<option value="LA">Louisiana</option>
				<option value="ME">Maine</option>
				<option value="MD">Maryland</option>
				<option value="MA">Massachusetts</option>
				<option value="MI">Michigan</option>
				<option value="MN">Minnesota</option>
				<option value="MS">Mississippi</option>
				<option value="MO">Missouri</option>
				<option value="MT">Montana</option>
				<option value="NE">Nebraska</option>
				<option value="NV">Nevada</option>
				<option value="NH">New Hampshire</option>
				<option value="NJ">New Jersey</option>
				<option value="NM">New Mexico</option>
				<option value="NY">New York</option>
				<option value="NC">North Carolina</option>
				<option value="ND">North Dakota</option>
				<option value="OH">Ohio</option>
				<option value="OK">Oklahoma</option>
				<option value="OR">Oregon</option>
				<option value="PA">Pennsylvania</option>
				<option value="RI">Rhode Island</option>
				<option value="SC">South Carolina</option>
				<option value="SD">South Dakota</option>
				<option value="TN">Tennessee</option>
				<option value="TX">Texas</option>
				<option value="UT">Utah</option>
				<option value="VT">Vermont</option>
				<option value="VA">Virginia</option>
				<option value="WA">Washington</option>
				<option value="WV">West Virginia</option>
				<option value="WI">Wisconsin</option>
				<option value="WY">Wyoming</option>
		         </select>
 					</div>
          
          <button type="submit" class="button button-block" />Get Started</button>
          
          </form>

        </div> -->
        
        <div id="login">   
          <h1>Welcome Back Admin!</h1>
          
          <form action="assets/php/login.php" method="post">
          
            <div class="field-wrap">
            <label>
              Email Address<span class="req">*</span>
            </label>
            <input type="email" name = "logEmail" required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Password<span class="req">*</span>
            </label>
            <input type="password" name ="logPass" required autocomplete="off"/>
          </div>
          
          <p class="forgot"><a href="#">Forgot Password?</a></p>
          
          <button class="button button-block"  />Log In</button>
          
          </form>

        </div>
        
      </div><!-- tab-content -->
      
</div> <!-- /form -->
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="assets/js/index.js"></script>

	
	
	
	
	
	
	
	
	
	
	
	
	
	

    <div class="section gray-light">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div id="main">
                        <div class="row">
                        </div>
                    </div>
                    <!-- /#main -->
                </div>
                <!-- /.col-md-12 -->
           </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /.section -->


<!-- /#content -->  <footer id="footer">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
				<div class="block random-cars">
					<div class="title">
						<h2>Popular Cars</h2>
					</div><!-- /.title -->

					<div class="items">
						<div class="teaser-item-wrapper">
							<div class="teaser-item">
							    <div class="title">
							        <a href="detail.html">Toyota Landcruiser</a>
							    </div><!-- /.title -->

		    					<div class="subtitle">Windsor Locks, CT </div><!-- /.subtitle -->

							    <div class="row">
							        <div class="picture-wrapper col-lg-4 col-md-4 col-sm-4 col-xs-4">
							            <div class="picture">
							                <a href="detail.html">
							                	<span class="hover">
							                		<span class="hover-inner">
							                			<i class="icon icon-normal-link"></i>
							                		</span><!-- /.hover-inner -->
							                	</span><!-- /.hover -->

							                    <img src="assets/img/content/toyota3.jpg" alt="#">
							                </a>
							            </div><!-- /.picture -->
							        </div><!-- /.picture-wrapper -->

							        <div class="content-wrapper col-lg-8 col-md-8 col-sm-8 col-xs-8">
							            <div class="price">$9,799</div>
							            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu vulputate neque. Fusce hendrerit fermentum.</p>
							        </div><!-- /.picture-content -->
							    </div><!-- /.row -->
							</div><!-- /.teaser-item -->
						</div><!-- /.teaser-item-wrapper -->

						<div class="teaser-item-wrapper">
							<div class="teaser-item">
							    <div class="title">
							        <a href="detail.html">Toyota Landcruiser</a>
							    </div><!-- /.title -->

		    					<div class="subtitle">Windsor Locks, CT </div><!-- /.subtitle -->

							    <div class="row">
							        <div class="picture-wrapper col-lg-4 col-md-4 col-sm-4 col-xs-4">
							            <div class="picture">
							                <a href="detail.html">
							                	<span class="hover">
							                		<span class="hover-inner">
							                			<i class="icon icon-normal-link"></i>
							                		</span><!-- /.hover-inner -->
							                	</span><!-- /.hover -->

							                    <img src="assets/img/content/toyota2.jpg" alt="#">
							                </a>
							            </div><!-- /.picture -->
							        </div><!-- /.picture-wrapper -->

							        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8 content-wrapper">
							            <div class="price">$9,799</div>
							            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent eu vulputate neque. Fusce hendrerit fermentum.</p>
							        </div><!-- /.content-wrapper -->
							    </div><!-- /.row -->
							</div><!-- /.teaser-item -->
						</div><!-- /.teaser-item-wrapper -->
					</div><!-- /.items -->
				</div><!-- /.block -->				
			</div><!-- /.col-md-4 -->

			<div class="col-lg-4 col-md-4 col-sm-6">
				<div class="block">
					<div class="title">
						<h2>Subscribe to Newsletter</h2>
					</div><!-- /.title -->

					<form method="post">
						<div class="input-group">						  
						  <input type="email" class="form-control" placeholder="Your e-mail address" required="required">

					      <span class="input-group-btn">
					        <button class="btn btn-default" type="button">Submit</button><!-- /.btn -->
					      </span><!-- /.input-group-btn -->
						</div><!-- /.input-group -->
					</form>

					<br>

					<div class="opening-hours">
						<div class="day clearfix">
							<span class="name">Monday</span><span class="hours">07:00 AM - 07:00 PM</span>
						</div><!-- /.day -->

						<div class="day clearfix">
							<span class="name">Tuesday</span><span class="hours">07:00 AM - 07:00 PM</span>
						</div><!-- /.day -->

						<div class="day clearfix">
							<span class="name">Wednesday</span><span class="hours"><i class="icon icon-normal-car"></i> Demonstration drives only</span>
						</div><!-- /.day -->

						<div class="day clearfix">
							<span class="name">Thursday</span><span class="hours">07:00 AM - 07:00 PM</span>
						</div><!-- /.day -->

						<div class="day clearfix">
							<span class="name">Friday</span><span class="hours">07:00 AM - 07:00 PM</span>
						</div><!-- /.day -->

						<div class="day clearfix">
							<span class="name">Saturday</span><span class="hours">07:00 AM - 02:00 PM</span>
						</div><!-- /.day -->

						<div class="day clearfix">
							<span class="name">Sunday</span><span class="hours"><i class="icon icon-normal-door-out"></i> Closed</span>
						</div><!-- /.day -->
					</div><!-- /.opening-hours -->		
				</div><!-- /.block -->
			</div><!-- /.col-md-4 -->

			<div class="col-lg-4 col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-2">
				<div class="block">
					<div class="title center-sm">
						<h2>Recent from Bazaar</h2>
					</div><!-- /.title -->

					<div id="carousel-example-generic" class="carousel slide gallery-grid" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
							<li data-target="#carousel-example-generic" data-slide-to="1"></li>
							<li data-target="#carousel-example-generic" data-slide-to="2"></li>
						</ol>
					  
						<div class="carousel-inner">
							<div class="item clearfix active">
								<div class="row">
									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota.jpg" alt="#">
											<span class="badge">Featured</span>
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota1.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota2.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->
								</div><!-- /.row -->

								<div class="row">
									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota3.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota.jpg" alt="#">
											<span class="badge">Best Price</span>
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota1.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->
								</div><!-- /.row -->

								<div class="row">
									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota.jpg" alt="#">
											<span class="badge">Elite Seller</span>
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota1.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota2.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->
								</div><!-- /.row -->
							</div><!-- /.item -->

							<div class="item clearfix">
								<div class="row">
									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota2.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota3.jpg" alt="#">
											<span class="badge">Quality A+</span>
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->
								</div><!-- /.row -->

								<div class="row">
									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota1.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota2.jpg" alt="#">
											<span class="badge">High Rating</span>
										</a>
									</div><!-- /.col-md-4 -->
								</div><!-- /.row -->

								<div class="row">
									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota2.jpg" alt="#">
											<span class="badge">Certified</span>
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota3.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->
								</div><!-- /.row -->
							</div><!-- /.item -->

							<div class="item clearfix">
								<div class="row">
									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota3.jpg" alt="#">
											<span class="badge">Elite Seller</span>
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota1.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->
								</div><!-- /.row -->

								<div class="row">
									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota2.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota3.jpg" alt="#">
											<span class="badge">Best Price</span>
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->
								</div><!-- /.row -->

								<div class="row">
									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota3.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota.jpg" alt="#">
										</a>
									</div><!-- /.col-md-4 -->

									<div class="image col-xs-4 col-md-4">
										<a href="detail.html">
						                	<span class="hover">
						                		<span class="hover-inner">
						                			<i class="icon icon-normal-link"></i>
						                		</span><!-- /.hover-inner -->
						                	</span><!-- /.hover -->

											<img src="assets/img/content/toyota1.jpg" alt="#">
											<span class="badge">High Quality</span>
										</a>
									</div><!-- /.col-md-4 -->																		
								</div><!-- /.row -->								
							</div><!-- /.item -->																			
						</div><!-- /.carousel-inner -->
					 
						<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
							<i class="icon icon-normal-left-arrow-small"></i>
						</a>

						<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
							<i class="icon icon-normal-right-arrow-small"></i>
						</a>
					</div><!-- /.carousel -->
				</div><!-- /.block -->
			</div><!-- /.col-md-4 -->			
		</div><!-- /.row -->
	</div><!-- /.container -->

	<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="col-md-12 clearfix">
					<div class="copyright">
						&copy; Carat HTML Template<span class="separator">/</span> <a href="http://pragmaticmates.com">Pragmatic Mates</a> <span class="separator">/</span> All rights reserved
					</div><!-- /.pull-left -->

					<ul class="nav nav-pills">
						<li><a href="#">Home</a></li>
						<li><a href="#">Features</a></li>
						<li><a href="#">Reservation</a></li>
						<li><a href="#">Our Offer</a></li>
						<li><a href="#">Contact</a></li>
					</ul><!-- /.nav -->
				</div><!-- /.col-md-12 -->
			</div><!-- /.row -->
		</div><!-- /.container -->
	</div><!-- /.footer-bottom -->
</footer><!-- /#footer -->


<script src="assets/js/jquery.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.js"></script>
<script src="assets/js/jquery.ui.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/cycle.js"></script>
<script src="libraries/jquery.bxslider/jquery.bxslider.js"></script>
<script src="libraries/easy-tabs/lib/jquery.easytabs.min.js"></script>
<script src="libraries/chosen/chosen.jquery.js"></script>
<script src="libraries/star-rating/jquery.rating.js"></script>
<script src="libraries/colorbox/jquery.colorbox-min.js"></script>
<script src="libraries/jslider/bin/jquery.slider.min.js"></script>
<script src="libraries/ezMark/js/jquery.ezmark.js"></script>

<script type="text/javascript" src="libraries/flot/jquery.flot.js"></script>
<script type="text/javascript" src="libraries/flot/jquery.flot.canvas.js"></script>
<script type="text/javascript" src="libraries/flot/jquery.flot.resize.js"></script>
<script type="text/javascript" src="libraries/flot/jquery.flot.time.js"></script>


<script src="http://maps.googleapis.com/maps/api/js?sensor=true&amp;v=3.13"></script>
<script src="assets/js/carat.js"></script></body>
</html>