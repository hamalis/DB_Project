<?php
session_start(); 
unset($_SESSION['login_user']); 
header("location: login.php"); 
   /*session_start();
  session_destroy();
unset($_SESSION);
header("Location: http://localhost:8080/project/content/HTML/register.html");*/
/*
   if(session_destroy()) {
      header("Location: login.php");
   }*/ 
?>