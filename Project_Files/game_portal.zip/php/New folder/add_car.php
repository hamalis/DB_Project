<?php

$mysql_host = 'localhost';
$mysql_user = 'root';
$mysql_password = 'root';

if(!@mysql_connect($mysql_host, $mysql_user, $mysql_password))
{
		 die('Unable to connect'); //or exit
}
else
{
	if(@mysql_select_db('cars'))
	{

	$first = $_POST["fn"];
	$last = $_POST["ln"];
	$email = $_POST["email"];
	$phone = $_POST["phone"];
	$address = $_POST["address"];
	$password = $_POST["pass"];
 
		$db = "INSERT INTO user_info (first_name,last_name,email,phone,address,password) VALUES ('$first','$last','$email','$phone','$address','$password') " ;
 				$q = mysql_query($db);
		if($q)
		{
				//echo "Singup Successfully";
				header( "location: http://localhost:8080/project/content/HTML/thank_you.php" );
 		}
		else
		{
			echo mysql_error();

		}
		 
	}
	else
	{
		die('Unable to connect'); //or exit
	}
}
 
?>
