<?php
   include('session_admin.php');
         header("Location: index_admin.php");

?>
  
                