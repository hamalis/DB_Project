<?php

$mysql_host = 'localhost';
$mysql_user = 'root';
$mysql_password = 'root';

$conn = mysql_connect($mysql_host, $mysql_user, $mysql_password);



if(!@mysql_connect($mysql_host, $mysql_user, $mysql_password))
{
		 die('Unable to connect'); //or exit
}
else
{
	if(@mysql_select_db('cars'))
	{

	
				$password = $_POST["logPass"];
				$email = $_POST["logEmail"];
				$password_entered = $password;
				$email_entered = $email;	
				$result = mysql_query("SELECT 2 FROM user_info WHERE email = '$email' AND password = '$password'");
					
		if($result && mysql_num_rows($result) > 0)
		{
			    
				
	$query="SELECT * FROM `user_info` WHERE Email = '$email' AND password = '$password'";
 	if($is_query_run=mysql_query($query))
	{
		 echo '<center><img src ="http://localhost/content/HTML/assets/img/connect_btn.gif" alt="ckeck" align="middle"></center>';
				header( "refresh:4;url=http://localhost/content/HTML/dealer.html" );
		 
	}
		
		 
 
		  else
		{
			 //echo " ";
			echo '<script language="javascript">';
			echo 'alert("not valid email or password")';
			echo '</script>';
			header( "refresh:0;url=http://localhost:8080/project/content/HTML/register.html" );
			//include 'http://localhost/content/HTML/register.html';
			//readfile('/');

		} 
		 
		}
			   /*$password = $_POST["logPass"];
				$email = $_POST["logEmail"];*/
					$result2 = mysql_query("SELECT 2 FROM admin_info WHERE email = '$email' AND password = '$password'");

	   if($result2 && mysql_num_rows($result2) > 0)
		{
			    
				
	$query2="SELECT * FROM `admin_info` WHERE Email = '$email' AND password = '$password'";
 	if($is_query_run=mysql_query($query2))
	{
		 echo '<center><img src ="http://localhost:8080/project/content/HTML/assets/img/connect_btn.gif" alt="ckeck" align="middle"></center>';
				header( "refresh:4;url=http://localhost:8080/project/content/HTML/admin.html" );
		 
	}
		   else
		{
			 //echo " ";
			echo '<script language="javascript">';
			echo 'alert("not valid email or password")';
			echo '</script>';
			header( "refresh:0;url=http://localhost:8080/project/content/HTML/register.html" );
			//include 'http://localhost/content/HTML/register.html';
			//readfile('/');

		}  
		
		}
	}
else
		{
			 //echo " ";
			echo '<script language="javascript">';
			echo 'alert("not valid email or password")';
			echo '</script>';
			header( "refresh:0;url=http://localhost:8080/project/content/HTML/register.html" );
			//include 'http://localhost/content/HTML/register.html';
			//readfile('/');

		}
	 
	
	/*else
	{
		die('Unable to connect'); //or exit
	}*/
}

?>
