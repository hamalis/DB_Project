 <?php
 session_save_path('session.php'); 
 ?>