<?php
   include('session.php');
         header("Location: index1.php");

?>
  
                