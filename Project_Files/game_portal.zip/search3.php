<html> 
<head>
</head>

<body>

<form action="search2.php" method="post">
  Search:<br>
  <input name="search" type="text">
  <br>
   
  <br><br>
  <input type="submit" value="Submit">
</form> 

</body>
</html>